package com.dotbhai.ffsecurity;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.net.URI;
import java.util.Locale;

public class MainActivity extends Activity {
    int bg = Color.rgb(12, 15, 24), panel = Color.rgb(25, 31, 46), accent = Color.rgb(255, 176, 32);
    LinearLayout root;
    EditText urlInput;
    TextView result;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(30), dp(22), dp(20));
        root.setBackgroundColor(bg);

        TextView brand = text("FF SECURITY SCANNER", 22, accent, true);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand);
        TextView sub = text("حماية حسابك تبدأ من الوعي", 15, Color.LTGRAY, false);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.bottomMargin = dp(26); root.addView(sub, sp);

        TextView heading = text("فحص رابط مشبوه", 18, Color.WHITE, true);
        root.addView(heading);
        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setHint("https://example.com");
        urlInput.setHintTextColor(Color.GRAY);
        urlInput.setTextColor(Color.WHITE);
        urlInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        urlInput.setBackgroundColor(panel);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(12); root.addView(urlInput, ip);

        Button scan = new Button(this);
        scan.setText("افحص الرابط");
        scan.setTextColor(Color.BLACK);
        scan.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(12); root.addView(scan, bp);

        result = text("النتيجة تظهر هنا. الفحص محلي ومبدئي ولا يضمن أن الرابط آمن.", 15, Color.WHITE, false);
        result.setPadding(dp(15), dp(15), dp(15), dp(15));
        result.setBackgroundColor(panel);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(18); root.addView(result, rp);

        TextView tipsTitle = text("نصائح لحماية حساب Free Fire", 18, accent, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(28); root.addView(tipsTitle, tp);

        String[] tips = {
            "• لا تشارك كلمة السر أو رموز التحقق مع أي شخص.",
            "• استعمل تسجيل الدخول الرسمي فقط.",
            "• تجنّب روابط الجوائز والشحن المجاني غير الموثوقة.",
            "• فعّل وسائل الحماية المتاحة لحسابك."
        };
        for (String tip : tips) {
            TextView t = text(tip, 15, Color.LTGRAY, false);
            t.setPadding(0, dp(9), 0, dp(2));
            root.addView(t);
        }

        TextView foot = text("FF Security Scanner • إصدار 1.0", 12, Color.GRAY, false);
        foot.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(24); root.addView(foot, fp);

        scan.setOnClickListener(v -> scanUrl());
        setContentView(root);
    }

    void scanUrl() {
        String raw = urlInput.getText().toString().trim();
        if (raw.isEmpty()) {
            result.setText("اكتب رابطاً أولاً.");
            return;
        }
        try {
            URI uri = URI.create(raw);
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
            String host = uri.getHost();
            String lower = raw.toLowerCase(Locale.ROOT);
            boolean suspicious = !scheme.equals("https") || host == null ||
                lower.contains("@") || lower.contains("xn--") ||
                lower.contains("free-fire-diamonds") || lower.contains("freefire-reward") ||
                lower.contains("login") && !host.endsWith("garena.com");
            if (suspicious) {
                result.setText("⚠️ الرابط يحتاج حذراً. ظهرت علامة أو أكثر قد تكون مريبة. لا تدخل بيانات حسابك.");
                result.setTextColor(Color.rgb(255, 190, 90));
            } else {
                result.setText("لم تظهر علامات مريبة أساسية، لكن هذا لا يثبت أن الرابط آمن. لا تدخل بياناتك إلا في الموقع الرسمي.");
                result.setTextColor(Color.rgb(150, 230, 170));
            }
        } catch (Exception e) {
            result.setText("صيغة الرابط غير واضحة. لا تفتحه إذا كنت غير متأكد منه.");
            result.setTextColor(Color.rgb(255, 190, 90));
        }
    }
}
